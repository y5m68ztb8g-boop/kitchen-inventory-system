import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import { execFile } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import type { IncomingMessage } from "node:http";
import { dirname, resolve } from "node:path";

const inventoryDatabasePath = resolve(process.cwd(), "local-data", "inventory-db.json");
const emptyInventoryDatabase = {
  deletedFreezerInventoryIds: [],
  dryStore: [],
  freezer: [],
  freezerSourceNameOverrides: {}
};

function readRequestBody(request: IncomingMessage) {
  return new Promise<string>((resolve, reject) => {
    let body = "";

    request.on("data", (chunk: Buffer) => {
      body += chunk.toString("utf8");
      if (body.length > 5 * 1024 * 1024) {
        reject(new Error("Request body is too large."));
      }
    });
    request.on("end", () => resolve(body));
    request.on("error", reject);
  });
}

function isAllowedExternalUrl(value: string) {
  try {
    const url = new URL(value);

    return url.protocol === "https:" && url.hostname === "www.brake.co.uk" && url.pathname === "/search";
  } catch {
    return false;
  }
}

async function readInventoryDatabase() {
  try {
    return JSON.parse(await readFile(inventoryDatabasePath, "utf8"));
  } catch {
    return emptyInventoryDatabase;
  }
}

async function writeInventoryDatabase(database: unknown) {
  await mkdir(dirname(inventoryDatabasePath), { recursive: true });
  await writeFile(inventoryDatabasePath, `${JSON.stringify(normalizeInventoryDatabase(database), null, 2)}\n`);
}

function normalizeInventoryDatabase(input: unknown) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return emptyInventoryDatabase;
  }

  const value = input as {
    deletedFreezerInventoryIds?: unknown;
    dryStore?: unknown;
    freezer?: unknown;
    freezerSourceNameOverrides?: unknown;
  };

  return {
    deletedFreezerInventoryIds: Array.isArray(value.deletedFreezerInventoryIds)
      ? value.deletedFreezerInventoryIds.filter((id): id is string => typeof id === "string")
      : [],
    dryStore: Array.isArray(value.dryStore) ? value.dryStore : [],
    freezer: Array.isArray(value.freezer) ? value.freezer : [],
    freezerSourceNameOverrides:
      value.freezerSourceNameOverrides &&
      typeof value.freezerSourceNameOverrides === "object" &&
      !Array.isArray(value.freezerSourceNameOverrides)
        ? Object.fromEntries(
            Object.entries(value.freezerSourceNameOverrides).filter(
              (entry): entry is [string, string] => typeof entry[1] === "string"
            )
          )
        : {}
  };
}

export default defineConfig({
  plugins: [
    react(),
    {
      name: "grow-naturally-external-opener",
      configureServer(server) {
        server.middlewares.use("/api/inventory-db", async (request, response) => {
          if (request.method === "GET") {
            response.setHeader("Content-Type", "application/json");
            response.end(JSON.stringify(await readInventoryDatabase()));
            return;
          }

          if (request.method === "POST") {
            try {
              const body = await readRequestBody(request);
              await writeInventoryDatabase(JSON.parse(body));
              response.statusCode = 204;
              response.end();
            } catch {
              response.statusCode = 400;
              response.end("Invalid inventory database");
            }
            return;
          }

          response.statusCode = 405;
          response.end("Method not allowed");
        });

        server.middlewares.use("/api/open-external", async (request, response) => {
          if (request.method !== "POST") {
            response.statusCode = 405;
            response.end("Method not allowed");
            return;
          }

          try {
            const body = await readRequestBody(request);
            const parsed = JSON.parse(body) as { url?: string };
            const url = parsed.url || "";

            if (!isAllowedExternalUrl(url)) {
              response.statusCode = 400;
              response.end("External URL is not allowed");
              return;
            }

            execFile("open", [url], (error) => {
              if (error) {
                response.statusCode = 500;
                response.end("Could not open external browser");
                return;
              }

              response.statusCode = 204;
              response.end();
            });
          } catch {
            response.statusCode = 400;
            response.end("Invalid request");
          }
        });
      }
    }
  ],
  test: {
    environment: "jsdom",
    environmentOptions: {
      jsdom: {
        url: "http://127.0.0.1:5173/"
      }
    },
    include: ["src/**/*.test.ts", "src/**/*.test.tsx"],
    setupFiles: "./src/test/setup.ts",
    globals: true
  }
});
